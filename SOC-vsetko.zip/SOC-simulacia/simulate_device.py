"""Software telemetry, NOT electrical simulation. Standard library only, localhost only."""
import argparse,json,time,urllib.request,urllib.error
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--scenario',choices=['normal','outage','source_empty','full','leak'],default='normal')
p.add_argument('--seconds',type=int,default=120)
p.add_argument('--configure-test',action='store_true',help='Configure the separate test database for ESP telemetry')
p.add_argument('--pause-link-at',type=float,default=-1)
p.add_argument('--pause-link-for',type=float,default=4)
a=p.parse_args();base='http://127.0.0.1:8876'
def call(path,body=None,method=None):
 data=None if body is None else json.dumps(body,allow_nan=False).encode()
 req=urllib.request.Request(base+'/api/'+path,data=data,method=method,headers={'Content-Type':'application/json','X-Device-Key':'soc-simulation-only'})
 with urllib.request.urlopen(req,timeout=2) as r:return json.load(r)
if a.configure_test:
 s=call('state')['settings'];s.update(configured=True,demo_mode=False,battery_capacity_mah=2500,prices_enabled=False,weather_enabled=False)
 call('settings',s,'PUT')
 call('water/config',dict(enabled=True,max_run_seconds=15,filter_service_minutes=60),'PUT')
print('SOFTWARE TEST ONLY. Data goes only to separate localhost test server port 8876.')
start=time.monotonic();last=start;lease_until=0;run_started=None;limit=15;fault='none';waterlevel=10
while time.monotonic()-start<a.seconds:
 now=time.monotonic();elapsed=now-start;dt=min(now-last,2);last=now
 grid=a.scenario!='outage';source=a.scenario!='source_empty';leak=a.scenario=='leak'
 full=a.scenario=='full' or waterlevel>=80;low=waterlevel<30
 if not grid:fault='main_lost'
 elif not source:fault='source_empty'
 elif leak:fault='leak'
 if run_started is not None and now-run_started>=limit:fault='timeout'
 if run_started is not None and now>=lease_until:fault='link_lost'
 running=run_started is not None and now<lease_until and not full and fault=='none'
 if running:waterlevel+=dt*9
 if not running:run_started=None
 v=3.8-.00005*elapsed if not grid else 3.9
 soc=max(0,min(100,50+(v-3.8)*150))
 payload=dict(device_id='software-test-only',firmware_version='test-bridge-1',telemetry_origin='software_test',
 panel_voltage_v=6,panel_current_a=.03,panel_power_w=.18,load_stage=3,grid_available=grid,
 battery_voltage_v=round(v,4),battery_current_a=-.25 if not grid else -.12,battery_soc_pct=round(soc,1),battery_soc_method='voltage_estimate',
 water=dict(source_ok=source,target_low=low,target_full=full,leak_detected=leak,pump_running=running,fault=fault))
 paused=a.pause_link_at>=0 and a.pause_link_at<=elapsed<a.pause_link_at+a.pause_link_for
 if paused:
  print('Link paused; virtual lease expires independently.')
 else:
  try:
   reply=call('device/telemetry',payload)['water_command']
   if reply.get('reset_fault') and grid and source and not leak:fault='none'
   allowed=reply['pump_on'] and grid and source and not full and not leak and fault=='none'
   if allowed:
    if run_started is None:run_started=now;limit=reply['max_run_ms']/1000
    lease_until=now+reply['lease_ms']/1000
   else:run_started=None
   print(f'{elapsed:5.1f}s TEST main={grid} SOC~{soc:.0f}% pump={running} level={waterlevel:.0f} fault={fault}')
  except (OSError,urllib.error.HTTPError) as e:print('No server connection:',type(e).__name__)
 time.sleep(1)
print('Test device stopped; app will mark it offline. No real pump was controlled.')
