"""Synthetic ESP telemetry. Talks only to the separate localhost:8876 test server."""
import argparse,json,time,urllib.request,urllib.error
p=argparse.ArgumentParser();p.add_argument('--scenario',choices=['normal','outage','shade','discharged'],default='normal');p.add_argument('--seconds',type=int,default=120);p.add_argument('--configure-test',action='store_true');p.add_argument('--pause-link-at',type=float,default=-1);p.add_argument('--pause-link-for',type=float,default=4);a=p.parse_args()
def call(path,body=None,method=None):
 data=None if body is None else json.dumps(body,allow_nan=False).encode()
 req=urllib.request.Request('http://127.0.0.1:8876/api/'+path,data=data,method=method,headers={'Content-Type':'application/json','X-Device-Key':'soc-simulation-only'})
 with urllib.request.urlopen(req,timeout=2) as r:return json.load(r)
if a.configure_test:
 s=call('state')['settings'];s.update(configured=True,demo_mode=False,battery_capacity_mah=2500,prices_enabled=False,weather_enabled=False);call('settings',s,'PUT')
print('SOFTWARE TEST ONLY. Separate localhost test server on port 8876.')
start=time.monotonic()
while time.monotonic()-start<a.seconds:
 elapsed=time.monotonic()-start;grid=a.scenario!='outage';shaded=a.scenario=='shade'
 v=3.5 if a.scenario=='discharged' else 3.8-.00005*elapsed if not grid else 3.9
 soc=max(0,min(100,50+(v-3.8)*150));amps=.003 if shaded else .03
 payload=dict(device_id='software-test-only',firmware_version='test-roof-2',telemetry_origin='software_test',panel_voltage_v=6,panel_current_a=amps,panel_power_w=round(6*amps,3),load_stage=3,grid_available=grid,battery_voltage_v=round(v,4),battery_current_a=-.25 if not grid else -.12,battery_soc_pct=round(soc,1),battery_soc_method='voltage_estimate')
 if a.pause_link_at>=0 and a.pause_link_at<=elapsed<a.pause_link_at+a.pause_link_for:print('TEST link paused')
 else:
  try:call('device/telemetry',payload);print(f'{elapsed:5.1f}s TEST main={grid} SOC~{soc:.0f}% panel={6*amps:.3f} W')
  except (OSError,urllib.error.HTTPError) as e:print('No test-server connection:',type(e).__name__)
 time.sleep(1)
print('Test device stopped; app will mark it offline.')
