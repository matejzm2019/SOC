"""Separate localhost-only app database and device key. Run with the SOC virtualenv Python."""
import argparse,os,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--project',type=Path,default=Path(__file__).resolve().parent.parent/'SOC');args=p.parse_args()
project=args.project.resolve();sys.path.insert(0,str(project))
os.environ['SOC_OFFLINE']='1'
from backend.main import create_app
import uvicorn
store=Path(__file__).resolve().parent/'data-simulacia';store.mkdir(exist_ok=True)
print('TEST SERVER: http://127.0.0.1:8876 · separate database, no real device key.')
uvicorn.run(create_app(database=store/'simulation.sqlite3',esp32_key='soc-simulation-only'),host='127.0.0.1',port=8876,workers=1)
