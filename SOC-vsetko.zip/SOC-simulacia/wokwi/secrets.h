#pragma once
#define WIFI_SSID "Wokwi-GUEST"
#define WIFI_PASSWORD ""
#define SERVER_URL "http://host.wokwi.internal:8876/api/device/telemetry"
#define DEVICE_KEY "soc-simulation-only"
