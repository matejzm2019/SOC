#pragma once
#define WIFI_SSID "NAZOV_WIFI"
#define WIFI_PASSWORD "HESLO_WIFI"
#define SERVER_URL "http://192.168.1.100:8765/api/device/telemetry"
#define DEVICE_KEY "SKOPIRUJ_DATA_DEVICE_KEY_TXT"
// Zapni az po zapojeni styroch plavakov a DRV8833 podla docs/ZAPOJENIE.md.
#ifndef WATER_ENABLED
#define WATER_ENABLED 0
#endif
