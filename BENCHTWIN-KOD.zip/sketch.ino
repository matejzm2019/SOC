// BenchTwin: electrical/controls test, NOT the production ESP32 firmware.
// Uses only the documented Arduino loop()/millis(), Serial and Wire support.
#include <Arduino.h>
#include <Wire.h>
const int SW[2] = {5, 6};
const int LED[2] = {7, 10};
bool candidate[2] = {false, false};
bool stable[2] = {false, false};
unsigned long changed[2] = {0, 0};
unsigned long sampled = 0;
unsigned long printed = 0;
bool mains = false;
float mainMillivolts = 0;

void scanSensors() {
  Serial.println("I2C scan: expected panel 0x40 and battery 0x41 if the model supports address selection.");
  for (int address = 0x40; address <= 0x41; address++) {
    Wire.beginTransmission(address);
    int result = Wire.endTransmission();
    Serial.print("Address ");
    Serial.print(address);
    Serial.print(" (decimal), result=");
    Serial.println(result); // 0 = ACK; 64 = 0x40, 65 = 0x41
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(4, INPUT);
  pinMode(5, INPUT_PULLUP);
  pinMode(6, INPUT_PULLUP);
  pinMode(7, OUTPUT);
  pinMode(10, OUTPUT);
  pinMode(11, OUTPUT);
  digitalWrite(7, LOW);
  digitalWrite(10, LOW);
  digitalWrite(11, LOW);
  analogReadResolution(12);
  Wire.begin(8, 9);
  Serial.println("BENCHTWIN TEST: A/B contacts, main supply ADC, status LED. Relay changes sources in hardware.");
  Serial.println("Send i to check I2C addresses. This sketch does not generate fake battery percentages or HTTP telemetry.");
}

void loop() {
  unsigned long now = millis();
  if ((unsigned long)(now - sampled) >= 10) {
    sampled = now;
    mainMillivolts = analogReadMilliVolts(4);
    if (mains) mains = mainMillivolts > 1200;
    else mains = mainMillivolts >= 1400;
    digitalWrite(11, mains ? HIGH : LOW);
    for (int i = 0; i < 2; i++) {
      bool raw = digitalRead(SW[i]) == LOW;
      if (raw != candidate[i]) {
        candidate[i] = raw;
        changed[i] = now;
      }
      if ((unsigned long)(now - changed[i]) >= 30) stable[i] = candidate[i];
      digitalWrite(LED[i], stable[i] ? HIGH : LOW);
    }
  }
  if (Serial.available() > 0) {
    int command = Serial.read();
    if (command == 'i' || command == 'I') scanSensors();
  }
  if ((unsigned long)(now - printed) >= 1000) {
    printed = now;
    Serial.print("MAIN="); Serial.print(mains ? 1 : 0);
    Serial.print(" A="); Serial.print(stable[0] ? 1 : 0);
    Serial.print(" B="); Serial.print(stable[1] ? 1 : 0);
    Serial.print(" main_ADC_mV="); Serial.println(mainMillivolts);
  }
  delay(1);
}
