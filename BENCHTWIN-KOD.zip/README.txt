BENCHTWIN – SKÚŠOBNÝ KÓD

Vlož sketch.ino do Code editora BenchTwin alebo importuj BENCHTWIN-KOD.zip
cez Code → Project → Import a .zip… . Nie je to import celej zapojenej scény.

Zapoj podľa ../BENCHTWIN-NAVOD.txt. Sketch skúša svetlá A/B,
ADC hlavného zdroja, modrú indikáciu a vie preveriť ACK na I2C.
Negeneruje percentá batérie ani aplikačnú telemetriu. Nabíjanie a zálohu
meraj virtuálnymi laboratórnymi nástrojmi podľa návodu.

Nevkladaj ho ako náhradu produkčného firmvéru na fyzický dom.
Produkčný kód 0.7.0-controls s FreeRTOS je v SOC/firmware/esp32-s3/.
